import express from "express";
import { Client, GatewayIntentBits, Partials } from "discord.js";
import Filter from "bad-words";

// 🔹 Setup Express server (keeps bot alive on Replit/Glitch/etc.)
const app = express();
const PORT = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("✅ Moda Bot is alive!");
});

app.listen(PORT, () => {
  console.log(`🌍 Web server running on port ${PORT}`);
});

// 🔹 Setup Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel] // Needed for DMs
});

const filter = new Filter();

client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

// 🔹 Profanity filter
client.on("messageCreate", async (message) => {
  if (message.author.bot) return; // Ignore bots

  if (filter.isProfane(message.content)) {
    try {
      await message.delete(); // Delete bad message

      // Send DM to the user (no public warning)
      await message.author.send(
        `🚫 Your message in **${message.guild.name}** was removed because it contained profanity:\n\n"${message.content}"`
      );
    } catch (err) {
      console.error("❌ Error deleting or DMing:", err);
    }
  }
});

// 🔹 Login
client.login(process.env.TOKEN);



