const fs = require('fs');
const path = require('path');

class Logger {
    constructor() {
        this.logDir = path.join(__dirname, '../logs');
        this.ensureLogDirectory();
    }
    
    ensureLogDirectory() {
        if (!fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }
    }
    
    formatMessage(level, message, extra = null) {
        const timestamp = new Date().toISOString();
        let logMessage = `[${timestamp}] [${level.toUpperCase()}] ${message}`;
        
        if (extra) {
            if (typeof extra === 'object') {
                logMessage += '\n' + JSON.stringify(extra, null, 2);
            } else {
                logMessage += ' ' + extra;
            }
        }
        
        return logMessage;
    }
    
    writeToFile(level, message) {
        const logFile = path.join(this.logDir, `bot-${new Date().toISOString().split('T')[0]}.log`);
        
        try {
            fs.appendFileSync(logFile, message + '\n');
        } catch (error) {
            console.error('Failed to write to log file:', error);
        }
    }
    
    log(level, message, extra = null) {
        const formattedMessage = this.formatMessage(level, message, extra);
        
        // Console output with colors
        switch (level) {
            case 'error':
                console.error('\x1b[31m%s\x1b[0m', formattedMessage); // Red
                break;
            case 'warn':
                console.warn('\x1b[33m%s\x1b[0m', formattedMessage); // Yellow
                break;
            case 'info':
                console.log('\x1b[36m%s\x1b[0m', formattedMessage); // Cyan
                break;
            case 'debug':
                console.log('\x1b[90m%s\x1b[0m', formattedMessage); // Gray
                break;
            default:
                console.log(formattedMessage);
        }
        
        // Write to file
        this.writeToFile(level, formattedMessage);
    }
    
    info(message, extra = null) {
        this.log('info', message, extra);
    }
    
    warn(message, extra = null) {
        this.log('warn', message, extra);
    }
    
    error(message, extra = null) {
        this.log('error', message, extra);
    }
    
    debug(message, extra = null) {
        this.log('debug', message, extra);
    }
}

module.exports = new Logger();
