const { EmbedBuilder } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
    name: 'help',
    description: 'Display available commands and their descriptions',
    
    async execute(message, args) {
        try {
            const { commands } = message.client;
            
            // Create an embed for better formatting
            const helpEmbed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🤖 Bot Commands')
                .setDescription('Here are all the available commands:')
                .setThumbnail(message.client.user.displayAvatarURL())
                .setTimestamp()
                .setFooter({
                    text: `Requested by ${message.author.tag}`,
                    iconURL: message.author.displayAvatarURL()
                });
            
            // Add fields for each command
            commands.forEach(command => {
                helpEmbed.addFields({
                    name: `!${command.name}`,
                    value: command.description || 'No description available',
                    inline: true
                });
            });
            
            // Add usage information
            helpEmbed.addFields({
                name: '📝 Usage',
                value: 'Use `!` prefix before each command (e.g., `!ping`)',
                inline: false
            });
            
            await message.reply({ embeds: [helpEmbed] });
            
            logger.info(`Help command executed by user: ${message.author.tag}`);
        } catch (error) {
            logger.error('Error in help command:', error);
            
            // Fallback to simple text message if embed fails
            try {
                const { commands } = message.client;
                let helpText = '📚 **Available Commands:**\n\n';
                
                commands.forEach(command => {
                    helpText += `**!${command.name}** - ${command.description || 'No description available'}\n`;
                });
                
                helpText += '\n💡 Use `!` prefix before each command (e.g., `!ping`)';
                
                await message.reply(helpText);
            } catch (fallbackError) {
                logger.error('Error in help command fallback:', fallbackError);
                throw fallbackError;
            }
        }
    }
};
