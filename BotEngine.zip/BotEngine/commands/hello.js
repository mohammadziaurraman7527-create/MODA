const logger = require('../utils/logger');

module.exports = {
    name: 'hello',
    description: 'Greet the user with a friendly message',
    
    async execute(message, args) {
        try {
            const user = message.author;
            const greetings = [
                `👋 Hello there, ${user.displayName || user.username}!`,
                `🎉 Hey ${user.displayName || user.username}, great to see you!`,
                `✨ Greetings, ${user.displayName || user.username}! How are you doing?`,
                `🌟 Hello ${user.displayName || user.username}! Welcome!`,
                `😊 Hi ${user.displayName || user.username}, nice to meet you!`
            ];
            
            const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
            
            await message.reply(randomGreeting);
            
            logger.info(`Hello command executed for user: ${user.tag}`);
        } catch (error) {
            logger.error('Error in hello command:', error);
            throw error;
        }
    }
};
