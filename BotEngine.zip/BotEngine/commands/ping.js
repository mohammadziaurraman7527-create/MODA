const logger = require('../utils/logger');

module.exports = {
    name: 'ping',
    description: 'Check bot latency and response time',
    
    async execute(message, args) {
        const startTime = Date.now();
        
        try {
            const reply = await message.reply('🏓 Pinging...');
            const endTime = Date.now();
            const latency = endTime - startTime;
            const apiLatency = Math.round(message.client.ws.ping);
            
            await reply.edit(`🏓 Pong!\n📊 **Latency:** ${latency}ms\n🌐 **API Latency:** ${apiLatency}ms`);
            
            logger.info(`Ping command executed - Latency: ${latency}ms, API: ${apiLatency}ms`);
        } catch (error) {
            logger.error('Error in ping command:', error);
            throw error;
        }
    }
};
