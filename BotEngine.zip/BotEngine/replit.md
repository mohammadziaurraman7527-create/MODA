# Discord Bot Project

## Overview

This is a Discord bot built using Discord.js v14 that implements a command-based architecture. The bot responds to messages with a `!` prefix and executes various commands including basic utility functions like ping, help, and greeting commands. The project features a modular command system where commands are dynamically loaded from the commands directory, making it easy to extend functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Discord.js v14**: Primary framework for Discord API interactions
- **Command Pattern**: Commands are implemented as separate modules with consistent structure (name, description, execute function)
- **Dynamic Command Loading**: Commands are automatically discovered and loaded from the `/commands` directory at startup
- **Collection-based Command Storage**: Uses Discord.js Collection for efficient command storage and retrieval

### Message Processing
- **Prefix-based Commands**: Uses `!` as command prefix for message parsing
- **Bot Message Filtering**: Automatically ignores messages from other bots to prevent loops
- **Error Handling**: Commands implement try-catch blocks with logging for error management

### Logging System
- **Custom Logger Utility**: Built-in logging system with multiple log levels (info, warn, error)
- **File-based Logging**: Daily log files stored in `/logs` directory with automatic directory creation
- **Console Output**: Color-coded console logging for development visibility
- **Structured Logging**: JSON formatting for complex objects and structured error reporting

### Command Architecture
- **Modular Design**: Each command is a separate file with standardized export structure
- **Async/Await Pattern**: All commands use modern async/await syntax for Promise handling
- **Rich Embeds**: Help command utilizes Discord embeds for enhanced visual presentation
- **User Context**: Commands have access to message context including author information and client instance

### Bot Configuration
- **Environment Variables**: Uses dotenv for configuration management
- **Gateway Intents**: Configured for Guilds, GuildMessages, and MessageContent permissions
- **Bot Status**: Sets custom activity and online status on ready event

## External Dependencies

### Core Dependencies
- **discord.js**: Discord API wrapper library for bot functionality
- **dotenv**: Environment variable management for configuration
- **Node.js Built-ins**: File system operations, path utilities, and core modules

### Discord API Integration
- **Gateway Connection**: Real-time message events and bot presence
- **REST API**: Message sending, editing, and embed functionality
- **Bot Permissions**: Requires message content intent and guild access

### File System Dependencies
- **Command Loading**: Dynamic file discovery and require() for command modules
- **Log File Management**: Automatic log directory creation and daily file rotation
- **Configuration**: Environment file reading for sensitive data like bot tokens